export interface Mesa {

   
id_Mesa: number;
tipomesa: number;
disponible:boolean;

}
