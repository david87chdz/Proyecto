import { Injectable } from '@angular/core';
import { Mesa } from './mesa';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MesasService {

  constructor() { 

  }


}
